//
//  ProfileViewController.h
//  Walk Through
//
//  Created by Nate Halbmaier on 2/15/14.
//  Copyright (c) 2014 Nate Halbmaier. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProfileManagement.h"

@interface ProfileViewController : UIViewController


@end
