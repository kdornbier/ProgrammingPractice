//
//  SearchCriteriaViewController.h
//  Walk Through
//
//  Created by Nate Halbmaier on 3/8/14.
//  Copyright (c) 2014 Nate Halbmaier. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchCriteriaViewController : UIViewController

@end
