//
//  EditProfileViewController.h
//  Walk Through
//
//  Created by Nate Halbmaier on 2/15/14.
//  Copyright (c) 2014 Nate Halbmaier. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProfileManagement.h"

@interface EditProfileViewController : UIViewController

@property (nonatomic, strong) ProfileManagement *profile;
@end
