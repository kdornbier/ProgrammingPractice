//
//  Walk_ThroughViewController.h
//  Walk Through
//
//  Created by Nate Halbmaier on 2/6/14.
//  Copyright (c) 2014 Nate Halbmaier. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>

@class GPPSignInButton;

@interface Walk_ThroughViewController : UIViewController

@end
