//
//  main.m
//  Walk Through
//
//  Created by Nate Halbmaier on 2/6/14.
//  Copyright (c) 2014 Nate Halbmaier. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Walk_ThroughAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Walk_ThroughAppDelegate class]));
    }
}
