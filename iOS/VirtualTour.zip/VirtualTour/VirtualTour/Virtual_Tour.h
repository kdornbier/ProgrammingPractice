//
//  Virtual_Tour.h
//  VirtualTour
//
//  Created by Kaitlyn Dornbier on 2/18/14.
//  Copyright (c) 2014 Kaitlyn Dornbier. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Virtual_TourViewpoint.h"

@interface Virtual_Tour : NSObject

@property (nonatomic, strong) NSMutableArray *viewPointArray;

@end
