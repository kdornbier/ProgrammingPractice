//
//  DPAppDelegate.h
//  Dynamics Project
//
//  Created by Kaitlyn Dornbier on 3/19/14.
//  Copyright (c) 2014 Kaitlyn Dornbier. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
