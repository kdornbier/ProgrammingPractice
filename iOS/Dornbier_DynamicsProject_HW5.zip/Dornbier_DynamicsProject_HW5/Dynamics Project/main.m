//
//  main.m
//  Dynamics Project
//
//  Created by Kaitlyn Dornbier on 3/19/14.
//  Copyright (c) 2014 Kaitlyn Dornbier. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DPAppDelegate class]));
    }
}
