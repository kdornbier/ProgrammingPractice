//
//  Dynamics_ProjectTests.m
//  Dynamics ProjectTests
//
//  Created by Kaitlyn Dornbier on 3/19/14.
//  Copyright (c) 2014 Kaitlyn Dornbier. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Dynamics_ProjectTests : XCTestCase

@end

@implementation Dynamics_ProjectTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
